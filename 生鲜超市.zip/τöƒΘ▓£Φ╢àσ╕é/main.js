import Vue from 'vue'
import App from './App'

import mock from 'common/mock/index.js'
import api from 'common/http/index.js'

Vue.config.productionTip = false

App.mpType = 'app'

const msg = (title, duration = 1500, mask = false, icon = 'none') => {
    //统一提示方便全局修改
    if (Boolean(title) === false) {
        return;
    }
    uni.showToast({
        title,
        duration,
        mask,
        icon
    });
}

// 引入 color ui 自定义导航
import cuCustom from './colorui/components/cu-custom.vue'
Vue.component('cu-custom',cuCustom)

Vue.prototype.$request = {
	mock,
	api,
	msg
}
Vue.prototype.$carList = [

]
Vue.prototype.$order = []

const app = new Vue({
    ...App
})
app.$mount()
