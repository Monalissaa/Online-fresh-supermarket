// import http from './interface'

import goods from './good.js'
import order from './order.js'

/**
 * 将业务所有接口统一起来便于维护
 * 如果项目很大可以将 url 独立成文件，接口分成不同的模块
 * 
 */

// 单独导出(测试接口) import {test} from '@/common/vmeitime-http/'




// 默认全部导出  import api from '@/common/vmeitime-http/'
export default {
	goods,
    order
}