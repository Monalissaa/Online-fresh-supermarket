const categoryList = [
	{
		id: 0,
		cate_name: '生鲜食品',
		children:[
			{
				id:0,
				cate_name:'叶菜类',
				pic:'http://demo.0769web.net/ecshop/ecshop0691shengxian/data/cat_ico/1499142800637754601.jpg'
			},
			{
				id:1,
        "pic":"http://demo.0769web.net/ecshop/ecshop0691shengxian/data/cat_ico/1499142867207721155.png",
        "cate_name":"根茎类"
			},
			{
				id:2,
        "pic":"http://demo.0769web.net/ecshop/ecshop0691shengxian/data/cat_ico/1499143045419074090.jpg",
        "cate_name":"菇菌类"}
				,
			{
				id:3,
      "pic":"http://demo.0769web.net/ecshop/ecshop0691shengxian/data/cat_ico/1499143005787615029.jpg",
        "cate_name":"瓜果类"},
			{
				id:4,
      "pic":"http://demo.0769web.net/ecshop/ecshop0691shengxian/data/cat_ico/1517193036038999524.png",
        "cate_name":"梨类"},
		]
	},
	{
		id: 1,
		cate_name: '粮油副食',
		children:[
			{
				id:0,
      "pic":"https://dss1.bdstatic.com/6OF1bjeh1BF3odCf/it/u=3526207660,831956731&fm=85&app=92&f=JPEG?w=121&h=75&s=31B6663203C573495D423A6503009069",
        "cate_name":"花生油"},
			{
				id:1,
      "pic":"https://dss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3490465705,748942242&fm=26&gp=0.jpg",
        "cate_name":"调和油"},
			{
				id:2,
      "pic":"https://t8.baidu.com/it/u=708155566,1054677609&fm=199&app=68&f=JPEG?w=375&h=375&s=1BD067865C43D2CC4027F6720300806D",
        "cate_name":"进口食用油"},
		]
	},
]

export default categoryList
