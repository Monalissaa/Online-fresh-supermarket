import listMenu from './listmenu.js'
import shopData, {categoryShopData} from './shopData.js'

import swiperList from './swiperlist.js'

import categoryList from './category.js'


const q = (dom)=>{
  const pic = dom.querySelector('img').currentSrc
  const cate_name = dom.querySelector('em').innerText
  copy(JSON.stringify({cate_name, pic}).replace('{', ''))
  console.log({
    pic,
    cate_name
  })
}

let t = (dom)=>{
  const items = dom.querySelectorAll('.product.flex_in.single_item')
  const result = []
  items.forEach(item => {
    const image = item.querySelector('img').currentSrc
    const store_name = item.querySelector('.proTitle a').innerText
    const price = item.querySelector('.proPrice span').innerText
    const s = {
      id:1, image, store_name, price
    }
    result.push(s)
  })
  console.log(result);
  copy(JSON.stringify(result))
}


export default{
	listMenu,
	shopData,
	swiperList,
	categoryList,
  categoryShopData
}
