const swiperList = [{
		id: 0,
		type: 'image',
		pic: 'http://demo.0769web.net/ecshop/ecshop0691shengxian/mobile/data/afficheimg/1449014580066418106.jpg'
	}, {
		id: 1,
		type: 'image',
		pic: 'http://demo.0769web.net/ecshop/ecshop0691shengxian/mobile/data/afficheimg/1449014633204150477.jpg',
	}, {
		id: 2,
		type: 'image',
		pic: 'http://demo.0769web.net/ecshop/ecshop0691shengxian/mobile/data/afficheimg/1499215874670723479.jpg'
	}, {
		id: 3,
		type: 'image',
		pic: 'http://demo.0769web.net/ecshop/ecshop0691shengxian/mobile/data/afficheimg/1449014605524349143.jpg'
	}, {
		id: 4,
		type: 'image',
  pic: 'http://demo.0769web.net/ecshop/ecshop0691shengxian/mobile/data/afficheimg/1449014580066418106.jpg'
	}];
	
	export default swiperList
