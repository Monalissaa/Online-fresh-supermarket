<template>
	<view class="container">
		<view class="item">
			<text class="text">收货人</text>
			<input type="text" placeholder="请填写收货人姓名" class="input">
		</view>
		<view class="item">
			<text class="text">手机号码</text>
			<input type="number" maxlength="11" placeholder="请填写收货人姓名" class="input">
		</view>
		<view class="item">
			<text class="text">所在地区</text>
			<input type="text" placeholder="省市县,乡镇等" class="input">
			<text class="iconfont iconlocation dingwei" @click="dingwei">定位</text>
		</view>
		<view class="item dizhi">
			<text class="text ">详细地址</text>
			<textarea value="" placeholder="街道,楼牌号等" class="textarea" />
		</view>
		<view class="default">
			<text class="text">设置默认地址</text>
			<view class="wrap" :class="isDefault ? 'wrap-active': ''" @click="clickDefault">
				<view class="dian" :class="isDefault ? 'dian-active': ''" >
					
				</view>
			</view>
		</view>
		
		
		<view class="saveBtn" @click="save">
			 保存并使用
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isDefault:false,
		
			}
		},
		methods: {
			//点击定位图标
			dingwei(){
				uni.chooseLocation({
					success: (res) => {
						console.log(res);
					}
				})
			},
			//点击是否默认地址按钮 
			clickDefault(){
				if(this.isDefault){
					this.isDefault = false
				}else{
					this.isDefault = true
				}
			},
			//保存
			save(){
				uni.navigateBack({
					delta:1
				})
			}
			
			
			
		}
	}
</script>

<style>
	page{background:#fff;}
	.container{
		width: 100vw;
		height: 100%;
		background-color: #FFFFFF;
		padding: 20rpx;

	}
	.item{
		display: flex;
		align-items: center;
		border-top: 1px solid #ececec;
		padding: 20rpx 0;
		font-size: 22rpx;
	}
	.dizhi{
		align-items: flex-start;
	}
	.item .text{
		font-weight: 600;
		width: 120rpx;
		font-size: 26rpx;
	}
	.item .input{
		display: inline-block;
		flex: 1;
		margin-left: 20rpx;
		font-size: 26rpx;


	}
	.item .textarea{
		font-size: 26rpx;
		margin-left: 20rpx;
		
		
	}
	.item .dingwei{
		font-size: 26rpx;
		font-weight: 900;
		/* margin-left: 20rpx; */
		color: rgba(211, 0, 0, 178);
		text-align: right;
	}
 
 
 /* 默认地址 */
	
	.default{
		font-size: 26rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-top: 1px solid #ececec;
		padding-top: 100rpx;
	}
	.default .text{
		color: #000000;
	}
	.default .wrap{
		border: 2px solid #dedede;
		width: 90rpx;
		height: 40rpx;
		display: flex;
		align-items: center;
		padding: 5rpx;
		border-radius: 50rpx;
	}
	.default .wrap .dian{
		width: 25rpx;
		height: 25rpx;
		background-color: #dedede;
		border-radius: 80rpx;
		box-shadow: 1px 1px 1px #dedede;
		align-self: flex-end;
		transition: all 500ms ease-out; 
	}
	.default .wrap>.dian-active{
		transform: translateX(50rpx);
		background-color: red;
	}
	.default>.wrap-active{
		border: 2px solid red;
	}
	
	
	/* 保存并使用 */
	
	.saveBtn{
		position: fixed;
		left: 50%;
		bottom: 0;
		width: 80%;
		transform: translate(-50%);
		background-color: red;
		padding: 20rpx;
		text-align: center;
		color: #FFFFFF;
		font-weight: 500;
		border-radius: 50rpx;
	}

</style>
