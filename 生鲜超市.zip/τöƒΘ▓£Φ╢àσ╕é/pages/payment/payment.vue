<template>
	<view class="container">
		<view class="header">
			<image src="../../static/icon/zhifuchenggong.png" mode="aspectFit" class="image"></image>
			<text>订单支付成功</text>
		</view>
		<view class="content-wrap">
			<view class="item">
				<text>订单编号:</text>
				<text>202011151516156151</text>
			</view>
			<view class="item">
				<text>实付金额:</text>
				<text style="color: #F0540E;">{{totalPrice}}元</text>
			</view>
			<view class="item">
				<text>支付方式:</text>
				<text>微信支付</text>
			</view>
			<view class="item">
				<text>收货人:</text>
				<text>张三 13512345678</text>
			</view>
			<view class="item">
				<text>收货地址:</text>
				<text>河南省郑州市中原区林山寨街道友爱路2号辉煌铭苑D座1601</text>
			</view>
		</view>

		<view class="bottom">
			<view class="bottom-item">

				<navigator url="../orderAll/orderAll"> 查看订单</navigator>

			</view>
			<view class="bottom-item" @click="goback" >
				返回首页

			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
        order: []
			}
		},
		methods: {
			goback(){
				uni.switchTab({
					url:'../index/index'
				})
			}
		},
    computed: {
      totalPrice() {
        return this.order.reduce((p,c)=>{
          console.log(p, c);
          return p + Number(c.price) * c.num
        }, 0).toFixed(2)
      },
    },
    onLoad(){
      console.log(this.$order, this.$carList);
      this.order = this.$carList
      this.$carList.forEach(v=>{
        v.status = 3
      })
    }

	}
</script>

<style>
	page{
		background-color: #FFFFFF;
	}
	.container{

		height: 80vh;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		align-items: center;

	}
	.header{
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-top: 120rpx;
	}
	.header .image{
		width: 130rpx;
		height: 130rpx;
		margin-bottom: 40rpx;
	}
	.header text{
		font-weight: 600;
		font-size: 32rpx;
	}

	.content-wrap{
		width: 100%;
		display: flex;
		flex-direction: column;
		align-self: flex-start;
		padding: 40rpx;
	}
	.content-wrap .item{
		margin-bottom: 20rpx;
	}
	.content-wrap .item text{
		font-size: 28rpx;
		color: #4d4d4d;
		letter-spacing: .5px;
		font-weight: 500;
	}
	.content-wrap .item text:first-of-type{
		display: inline-block;
		width: 170rpx;
	}
	.content-wrap .item:nth-child(4) {
		border-top: 1px solid #d6d6d6;
		padding-top: 20rpx;
	}

	.bottom{
		width: 80%;
		display: flex;
		flex-direction: column;
		justify-content: space-between;

	}
	.bottom .bottom-item{

		border: 1px solid #999999;
		padding: 20rpx;
		text-align: center;
		font-size: 30rpx;
		border-radius: 50rpx;
		font-weight: 500;
		color: #666666;
	}
	.bottom .bottom-item:last-of-type{
		background: linear-gradient(to left,#ff9353,#ff6e53);
		color: #FFFFFF;
		margin-top: 30rpx;
	}
</style>
