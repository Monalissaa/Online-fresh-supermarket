<template>
	<view class="container">
		
		<image src="../../static/mayun.jpg" mode="" class="image"></image>
		<view class="content">
			
			<view class="login-input">
				<view class="login-wrap">
						<text class="iconfont iconwode1"></text>
						<input type="text" value="" placeholder="请输入手机号" maxlength="11" />
				</view>
				<view class="login-wrap">
						<text class="iconfont iconmima"></text>
						<input type="text" value="" maxlength="6" placeholder="请输入验证码" />
						<view class="yzmBtn">
							获取验证码
						</view>
				</view>
			 
			</view>
			
			
			
			<view class="tijiaobtn" @click="loginBtn">
				登录
			</view>
		</view>
		 
	</view>
</template>

<script>
 
	export default {
 
		data() {
			return {
				
			};
		},
		methods:{
			//登录BTn
			loginBtn(){
				uni.reLaunch({
					url:'../user/user'
				})
			}
		}
	}
</script>

<style>
	page{
		background-image: linear-gradient(45deg, #0081ff, #1cbbb4);;
	}
	.container{
		display: flex;
		flex-direction: column;
		
		align-items: center;
	}
	.image{
		width: 200rpx;
		height: 200rpx;
		border-radius: 50%;
		margin: 120rpx 0;
	}
	.content{
		width: 85%;
		height: 500rpx;
		background-color: #FFFFFF;
		border-radius: 5%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-around;
		
		box-shadow:10px 15px 35px rgba(0,0,0,0.5);
	}
	.login-input{
		/* padding: 0 40rpx; */
 
	}
	.login-input .login-wrap{
		display: flex;
		align-items: center;
		height: 80rpx;
		border-bottom: 1px solid #EFEFEF;
		margin-top: 50rpx;
	}
	.login-input .login-wrap text{
		margin: 0 20rpx;
		font-size: 40rpx;
	}
	.login-input .login-wrap input{
		font-size: 33rpx;
	}
	.login-input .login-wrap .yzmBtn{
		float: right;
		width: 200rpx;
		margin-right: 20rpx;
		background-color: #f35446;
		padding: 10rpx;
		border-radius: 30rpx;
		text-align: center;
		color: #FFFFFF;
	}
	
	
	/* 登录按钮 */
	.tijiaobtn{
		background-image: linear-gradient(45deg, #0081ff, #1cbbb4);
		width: 80%;
		padding: 20rpx 0;
		text-align: center;
		font-size: 40rpx;
		color: #FFFFFF;
		font-weight: 700;
		box-shadow: 5px 5px 15px #888888;
		border-radius: 30rpx;
	}
	

</style>
